console.log("I got a rainbow")
console.log("And an extension called Codachi. His name is Gidget and will level up as I code!")