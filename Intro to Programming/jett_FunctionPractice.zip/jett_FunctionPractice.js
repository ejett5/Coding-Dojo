/*
//take user name and reference it in greeting
let person = prompt ("Please enter your name:" , "");
//greeting [name], it is {time of day, morning/afternoon/etc.}
if (person == Dooku){
    return(prompt = "Greetings Count, I am coming for you. The time of the Sith is over, and not soon enough.")
}else{
    return("Hello" + person + "The time is" + new Date)
}
*/

//establish variable to track set pieces of cake and guests
var numberPieces = 12;
var numberOfPeople = 5;
//calculating the remaining pieces of cake 
return howMuchLeftOverCake = numberPieces - numberPeople
console.log("There are:" + howMuchLeftOverCake +" pieces of cake remaining. Eat Up you slackers!" )