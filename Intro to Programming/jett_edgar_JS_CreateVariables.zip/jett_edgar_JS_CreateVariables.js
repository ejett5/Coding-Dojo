//setting up variables to take input to determine if someone is able to ride the ride given the parameters in the loop section
var height = 43;
var age =11 ;


//using variables to determine if child is able to ride the ride
if (height >= 42 && age >= 10){
    message = "You can ride!";
        } else{
            message = "You cannot ride this ride. Come back again.";
        }
//printing the result of the variables and the elif loop 
//TODO get the result to print
    console.log(message)