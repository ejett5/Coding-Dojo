//the result of that function would be: I was born in 1980

//the result of taking input would be the string "I was born in" plus the user input to form a string the same as before.

//10 and 20 would be added to make a sum of 30 for both as they are just taking the input in different ways for the same result